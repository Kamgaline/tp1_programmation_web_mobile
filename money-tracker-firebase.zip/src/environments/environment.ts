// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBmjchx1UytI_3FFVhUjTyAbEPQCyh9IDI",
    authDomain: "money-tracking-7d902.firebaseapp.com",
    projectId: "money-tracking-7d902",
    storageBucket: "money-tracking-7d902.appspot.com",
    messagingSenderId: "636273733668",
    appId: "1:636273733668:web:9a8fce02907ea2de7768b1"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
